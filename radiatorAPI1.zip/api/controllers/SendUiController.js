/**
 * SendUiController
 *
 * @description :: Server-side logic for managing senduis
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

	view_data:function(req,res){
			var db = sails.db;
			db.collection('latest_data',function(err, coll){
							 if(err) throw err;
							 coll.find().toArray(function(err, items){
								 delete items[0]._id;
								 return res.json(items);
							 })
						 })

		},

		view_services:function(req,res){
			var db = sails.db;
			db.collection('latest_data',function(err, coll){
							 if(err) throw err;
							 coll.find().toArray(function(err, items){
								 delete items[0]._id;
								 var services = [];
								 for(i in items[0]){
									 services.push(i);
								 }
								 return res.json(services);
							 })
						 })

		},

		get_all:function(req, res){
			var myObj = {};
	    myObj["username"] = req.body.username;
	    myObj["password"] =req.body.password;
	    myObj["host"] =req.body.host;
	    myObj["database"] =req.body.database;
	    myObj["port"] = req.body.port;
	    myObj["adapter"] = req.body.adapter;
			myObj["service"] = req.body.service;
	    sails.log(myObj);

	    var db = sails.db;
	    sails.log('inside mongo');
			db.collection('mongo',function(err, coll){
	    sails.log('inside db');
							 if(err) throw err;
							 coll.insert(myObj,function(err, items){
	               sails.log('inside coll');
	              if(err) throw err;
								 return res.json(items);
							 })
						 })
		},

		view_service_data:function(req, res){
			var db = sails.db;
			db.collection('latest_data',function(err, coll){
							 if(err) throw err;
							 coll.find().toArray(function(err, items){
								 delete items[0]._id;
								 return res.json(items[0][req.params.service]);
							 })
						 })
			//console.log(req.params.service);

		}

};
