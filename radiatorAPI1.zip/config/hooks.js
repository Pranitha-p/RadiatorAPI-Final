/* Disable grunt and sockets automation/integration */

module.exports.hooks = {
  sockets: false,
  grunt: false,
};
